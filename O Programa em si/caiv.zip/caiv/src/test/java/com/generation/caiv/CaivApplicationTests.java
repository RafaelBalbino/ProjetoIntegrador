package com.generation.caiv;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CaivApplicationTests {

	@Test
	void contextLoads() {
	}

}
