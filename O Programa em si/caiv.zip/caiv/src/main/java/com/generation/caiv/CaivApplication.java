package com.generation.caiv;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CaivApplication {

	public static void main(String[] args) {
		SpringApplication.run(CaivApplication.class, args);
	}

}
